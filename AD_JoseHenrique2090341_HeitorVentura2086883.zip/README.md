# dsatur
DSATUR implementation in C.

## Executar
Rode `make` para executar o projeto.

OBS: Executado num sistema operacional Linux com gcc e cat instalados.

## Participantes no desenvolvimento
Heitor Tonel Ventura (2086883) e José Henrique Ivanchechen (2090341)

## Repositório

https://github.com/heitortv/dsatur